public class Parser {

    static String[] OPERATORS = {"+", "-", "*", "/"};
    static String[] ARABIC = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
    static String[] ROMAN = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    private int getOperatorIndex(String input) {
        int retval = -1;
        for (String operator : OPERATORS) {
            if (input.contains(operator)) {
                retval = input.indexOf(operator);
                break;
            }
        }
        return retval;
    }

    private boolean checkForArabic(String input) {
        boolean retval = false;
        for (String s : ARABIC) {
            if (input.equals(s)) {
                retval = true;
                break;
            }
        }
        return retval;
    }

    private boolean checkForRoman(String input) {
        boolean retval = false;
        for (String s : ROMAN) {
            if (input.equals(s)) {
                retval = true;
                break;
            }
        }
        return retval;
    }


    private int convertRomanToArabic(String in) {
        int retval = -1;
        for (int i = 0; i < ROMAN.length; i++) {
            String ro = ROMAN[i];
            if (in.equals(ro)) {
                retval = i + 1;
                break;
            }
        }

        return retval;
    }


    public void parse(String input) {
        Calculator cal = new Calculator();
        int indexOfOperator = getOperatorIndex(input);
        if (indexOfOperator != -1) {
            String a = input.substring(0, indexOfOperator);
            String b = input.substring(indexOfOperator + 1);
            String op = input.substring(indexOfOperator, indexOfOperator + 1);
            if (checkForArabic(a.trim()) && checkForArabic(b.trim())) {
                int aIn = Integer.parseInt(a.trim());
                int bIn = Integer.parseInt(b.trim());
                int result = cal.calculate(aIn, bIn, op);
                System.out.println("arabic " + result);
            } else if (checkForRoman(a.trim()) && checkForRoman(b.trim())) {
                int aIn = convertRomanToArabic(a.trim());
                int bIn = convertRomanToArabic(b.trim());
                int number = cal.calculate(aIn, bIn, op);
                String result = RomanNumber.toRoman(number);
                System.out.println("roman " + result);
            } else {
                throw new ArithmeticException("one of the characters is not arabic or roman!");
            }

        } else {
            throw new ArithmeticException("No operator!");
        }


    }


    public static void main(String[] args) {


    }

}