public class Calculator {
    public int calculate(int a, int b, String op) {
        int retval = 0;
        if (op.equals("+")) {
            retval = a + b;
        }
        if (op.equals("-")) {
            retval = a - b;
        }
        if (op.equals("*")) {
            retval = a*b;
        }
        if (op.equals("/")) {
            retval = a/b;
        }
        return retval;
    }

    public static void main(String[] args) {
    }
}