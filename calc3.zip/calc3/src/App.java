import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class App {

    public static void main(String[] args)
            throws IOException {
        while (true) {
            System.out.println("Input: ");
            // Enter data using BufferReader
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(System.in));

            // Reading data using readLine
            String input = reader.readLine();

            // Printing the read line
            Parser parser = new Parser();
            parser.parse(input);

        }
    }
}